<footer class="cf">
	<div class= "container">
		<p class="copyright">&copy; 2014 Karine Wu Jye</p>

		<ul class="footer-nav">
			<li><a href="about.php">About</a></li>
			<li><a href="policy.php">Policy</a></li>
			<li><a href="#">Contact</a></li>
		</ul>
	</div>
</footer>

</body>
</html>